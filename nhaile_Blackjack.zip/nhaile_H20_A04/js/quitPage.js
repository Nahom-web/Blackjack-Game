$$ = sel => document.querySelector(sel);
$$("#pName").innerHTML = localStorage.previousName;
$$("#moneyMade").innerHTML = localStorage.moneyEarned;